package org.sunny.afstream;

import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

final class HttpDownloader extends Downloader {
    private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:140.0) Gecko/20100101 Firefox/140.0";
    private static final Set<String> SKIP = Set.of("host", "content-length", "connection", "expect", "upgrade");
    private final HttpClient http;

    HttpDownloader() {
        HttpClient.Builder builder = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(15));
        SSLContext ssl = trust();
        if (ssl != null) builder.sslContext(ssl);
        http = builder.build();
    }

    public Response execute(Request request) throws IOException {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(request.url())).timeout(Duration.ofSeconds(30));
        b.header("User-Agent", USER_AGENT);
        for (Map.Entry<String, List<String>> e : request.headers().entrySet()) {
            String key = e.getKey();
            if (SKIP.contains(key.toLowerCase(Locale.ROOT))) continue;
            for (String value : e.getValue()) {
                if (key.equalsIgnoreCase("user-agent")) b.setHeader(key, value);
                else b.header(key, value);
            }
        }
        byte[] body = request.dataToSend();
        b.method(request.httpMethod(), body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(body));
        try {
            HttpResponse<String> res = http.send(b.build(), HttpResponse.BodyHandlers.ofString());
            return new Response(res.statusCode(), "", res.headers().map(), res.body(), res.uri().toString());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException(e);
        }
    }

    private static SSLContext trust() {
        if (!System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win")) return null;
        try {
            List<X509TrustManager> managers = new ArrayList<>();
            managers.add(manager(null));
            KeyStore windows = KeyStore.getInstance("Windows-ROOT");
            windows.load(null, null);
            managers.add(manager(windows));
            X509TrustManager any = new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] chain, String auth) throws CertificateException {
                    managers.get(0).checkClientTrusted(chain, auth);
                }

                public void checkServerTrusted(X509Certificate[] chain, String auth) throws CertificateException {
                    CertificateException last = null;
                    for (X509TrustManager m : managers) {
                        try {
                            m.checkServerTrusted(chain, auth);
                            return;
                        } catch (CertificateException e) {
                            last = e;
                        }
                    }
                    throw last;
                }

                public X509Certificate[] getAcceptedIssuers() {
                    List<X509Certificate> all = new ArrayList<>();
                    for (X509TrustManager m : managers) all.addAll(List.of(m.getAcceptedIssuers()));
                    return all.toArray(new X509Certificate[0]);
                }
            };
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(null, new TrustManager[]{any}, null);
            return ctx;
        } catch (Exception e) {
            return null;
        }
    }

    private static X509TrustManager manager(KeyStore store) throws Exception {
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(store);
        for (TrustManager m : tmf.getTrustManagers()) if (m instanceof X509TrustManager x) return x;
        throw new IllegalStateException("No TrustManager");
    }
}
