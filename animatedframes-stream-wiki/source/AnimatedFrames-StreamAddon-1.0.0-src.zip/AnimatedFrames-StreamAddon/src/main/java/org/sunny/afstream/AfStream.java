package org.sunny.afstream;

import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.StreamType;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class AfStream {
    public static final String VERSION = "1.0.0";
    private static final int MAX_HEIGHT = 1080;
    private static volatile boolean ready;

    private AfStream() {}

    private static synchronized void init() {
        if (ready) return;
        NewPipe.init(new HttpDownloader());
        ready = true;
    }

    public static boolean accepts(String url) {
        try {
            return ServiceList.YouTube.getStreamLHFactory().acceptUrl(url);
        } catch (Exception e) {
            return false;
        }
    }

    public static String[] resolve(String url) throws Exception {
        init();
        StreamInfo info = StreamInfo.getInfo(ServiceList.YouTube, url);
        String hls = info.getHlsUrl();
        boolean live = info.getStreamType() == StreamType.LIVE_STREAM || info.getStreamType() == StreamType.AUDIO_LIVE_STREAM;
        if (live && hls != null && !hls.isEmpty()) return new String[]{hls, hls};
        VideoStream video = best(info.getVideoOnlyStreams(), true);
        if (video == null) video = best(info.getVideoOnlyStreams(), false);
        AudioStream audio = info.getAudioStreams().stream()
                .filter(s -> s.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP)
                .max(Comparator.<AudioStream>comparingInt(s -> isM4a(s) ? 1 : 0).thenComparingInt(AudioStream::getAverageBitrate))
                .orElse(null);
        if (video != null && audio != null) return new String[]{video.getContent(), audio.getContent()};
        VideoStream muxed = best(info.getVideoStreams(), false);
        if (muxed != null) return new String[]{muxed.getContent(), muxed.getContent()};
        if (hls != null && !hls.isEmpty()) return new String[]{hls, hls};
        throw new IllegalStateException("YouTube returned no stream for " + url);
    }

    private static VideoStream best(List<VideoStream> streams, boolean avcOnly) {
        return streams.stream()
                .filter(s -> s.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP)
                .filter(s -> s.getHeight() > 0 && s.getHeight() <= MAX_HEIGHT)
                .filter(s -> !avcOnly || (s.getCodec() != null && s.getCodec().toLowerCase(Locale.ROOT).startsWith("avc1")))
                .max(Comparator.comparingInt(VideoStream::getHeight).thenComparingInt(VideoStream::getFps))
                .orElse(null);
    }

    private static boolean isM4a(AudioStream s) {
        return s.getFormat() != null && s.getFormat().name().startsWith("M4A");
    }
}
